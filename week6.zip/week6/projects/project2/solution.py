# Project 2 - Number Guessing Game
# Author: student

import random

secret = random.randint(1, 10)
guesses = 0

while True:
    raw = input("Guess a number between 1 and 10: ")

    try:
        guess = int(raw)
    except ValueError:
        print("Invalid input. Enter a whole number.")
        continue

    if guess < 1 or guess > 10:
        print("Please enter a number from 1 to 10.")
        continue

    guesses += 1

    if guess < secret:
        print("Too low! Try again.")
    elif guess > secret:
        print("Too high! Try again.")
    else:
        break

print(f"Correct! You got it in {guesses} guesses.")
