# Project 5 - Mini Shopping Cart
# Author: student

menu = {
    1: ("Apple", 0.50),
    2: ("Banana", 0.30),
    3: ("Milk", 1.20),
    4: ("Bread", 2.00),
}

prices = {name: price for _, (name, price) in menu.items()}
cart = {}
total = 0.0

print("--- Shop Menu ---")
for number, (name, price) in menu.items():
    print(f"{number}. {name:<8} ${price:.2f}")
print("5. Done")

while True:
    raw = input("Choose an item (1-5): ")

    try:
        choice = int(raw)
    except ValueError:
        print("Invalid choice, enter a number from 1 to 5.")
        continue

    if choice == 5:
        break

    if choice in menu:
        name, price = menu[choice]
        cart[name] = cart.get(name, 0) + 1
        total += price
        print(f"Added {name}. Total: ${total:.2f}")
    else:
        print("Invalid choice, try again.")

print("\n--- Receipt ---")
if cart:
    for item, qty in cart.items():
        line_total = prices[item] * qty
        print(f"{item:<8} x{qty:<2} ${line_total:.2f}")
else:
    print("Cart is empty.")

print("---------------------")
print(f"Total: ${total:.2f}")
print("Thank you!")
