# Project 1 - Temperature Converter
# Author: student

try:
    celsius = float(input("Enter temperature in Celsius: "))
except ValueError:
    print("Invalid input. Please enter a numeric value.")
else:
    fahrenheit = (celsius * 9 / 5) + 32
    print(f"{celsius:.1f}C = {fahrenheit:.1f}F")
