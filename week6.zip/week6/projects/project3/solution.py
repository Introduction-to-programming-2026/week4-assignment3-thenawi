# Project 3 - Grade Calculator
# Author: student

scores = []

for i in range(5):
    while True:
        raw = input(f"Enter score {i + 1}: ")

        try:
            score = float(raw)
        except ValueError:
            print("Invalid input. Please enter a number between 0 and 100.")
            continue

        if score < 0 or score > 100:
            print("Score must be between 0 and 100.")
            continue

        scores.append(score)
        break

average = sum(scores) / len(scores)

if average >= 90:
    grade = "A"
elif average >= 80:
    grade = "B"
elif average >= 70:
    grade = "C"
elif average >= 60:
    grade = "D"
else:
    grade = "F"

print(f"Average: {average:.1f}")
print(f"Grade: {grade}")
