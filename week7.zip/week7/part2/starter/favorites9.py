# favorites9.py
# Task: Count languages using SQL instead of a Python dictionary.

from cs50 import SQL

# Open the database
db = SQL("sqlite:///favorites.db")

rows = db.execute(
    "SELECT language, COUNT(*) AS n FROM favorites GROUP BY language ORDER BY n DESC"
)

for row in rows:
    print(row["language"], row["n"])
