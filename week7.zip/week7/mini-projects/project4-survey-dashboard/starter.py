# starter.py - Survey Dashboard

import csv
import sqlite3

conn = sqlite3.connect("survey.db")
db = conn.cursor()

db.execute(
    """
    CREATE TABLE IF NOT EXISTS responses (
        student_id TEXT,
        faculty TEXT,
        year INTEGER,
        satisfaction INTEGER,
        favourite_tool TEXT,
        comments TEXT
    )
    """
)

db.execute("DELETE FROM responses")

csv_files = [
    "faculty_science.csv",
    "faculty_arts.csv",
    "faculty_business.csv",
]

for filename in csv_files:
    with open(filename, "r") as file:
        reader = csv.DictReader(file)
        for row in reader:
            db.execute(
                "INSERT INTO responses VALUES (?, ?, ?, ?, ?, ?)",
                (
                    row["student_id"],
                    row["faculty"],
                    int(row["year"]),
                    int(row["satisfaction"]),
                    row["favourite_tool"],
                    row["comments"],
                ),
            )

conn.commit()
print("Database loaded successfully.\n")

print("=" * 30)
print("  UNIVERSITY SURVEY DASHBOARD")
print("=" * 30)

print("\n1. Total Responses by Faculty")
rows = db.execute(
    "SELECT faculty, COUNT(*) AS n FROM responses GROUP BY faculty ORDER BY faculty"
).fetchall()
total = 0
for row in rows:
    print(f"   {row[0]:<10}: {row[1]}")
    total += row[1]
print(f"   {'TOTAL':<10}: {total}")

print("\n2. Average Satisfaction by Year of Study")
rows = db.execute(
    "SELECT year, ROUND(AVG(satisfaction), 1) AS avg_sat "
    "FROM responses GROUP BY year ORDER BY year"
).fetchall()
for row in rows:
    print(f"   Year {row[0]} : {row[1]:.1f} / 5")

print("\n3. Favourite Tool Popularity")
rows = db.execute(
    "SELECT favourite_tool, COUNT(*) AS n "
    "FROM responses GROUP BY favourite_tool ORDER BY n DESC, favourite_tool"
).fetchall()
for row in rows:
    print(f"   {row[0]:<6} : {row[1]:>2} students")

print("\n4. Faculty Comparison")
print(f"   {'Faculty':<12} | {'Avg Satisfaction':<18} | Most Popular Tool")
print("   " + "-" * 50)

faculties = ["Arts", "Business", "Science"]
for faculty in faculties:
    avg_row = db.execute(
        "SELECT ROUND(AVG(satisfaction), 1) AS avg FROM responses WHERE faculty = ?",
        (faculty,),
    ).fetchone()

    tool_row = db.execute(
        "SELECT favourite_tool, COUNT(*) AS n FROM responses "
        "WHERE faculty = ? GROUP BY favourite_tool "
        "ORDER BY n DESC, favourite_tool LIMIT 1",
        (faculty,),
    ).fetchone()

    avg_value = avg_row[0] if avg_row and avg_row[0] is not None else 0.0
    top_tool = tool_row[0] if tool_row else "N/A"
    print(f"   {faculty:<12} | {avg_value:<18} | {top_tool}")

print()
try:
    min_score = int(input("Enter minimum satisfaction score (1-5): "))
except ValueError:
    print("Invalid input. Defaulting to 4.")
    min_score = 4

if min_score < 1:
    min_score = 1
elif min_score > 5:
    min_score = 5

rows = db.execute(
    "SELECT student_id, faculty, year, favourite_tool "
    "FROM responses WHERE satisfaction >= ? "
    "ORDER BY faculty, year, student_id",
    (min_score,),
).fetchall()

print(f"\nStudents with satisfaction >= {min_score}:")
if not rows:
    print("  No results found.")
for row in rows:
    print(f"  {row[0]} | {row[1]:<8} | Year {row[2]} | {row[3]}")

conn.close()
