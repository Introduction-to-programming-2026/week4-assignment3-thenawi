# favorites1.py
# Task: Same as favorites0, but store the language in a variable called 'favorite'

import csv

with open("favorites.csv", "r") as file:
    reader = csv.reader(file)
    next(reader)
    for row in reader:
        favorite = row[1]
        print(favorite)
