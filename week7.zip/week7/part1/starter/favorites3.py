# favorites3.py
# Task: Same as favorites2 but print directly without a named variable.

import csv

with open("favorites.csv", "r") as file:
    reader = csv.DictReader(file)
    for row in reader:
        print(row["language"])
