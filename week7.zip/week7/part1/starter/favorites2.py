# favorites2.py
# Task: Print every language using csv.DictReader instead of csv.reader

import csv

with open("favorites.csv", "r") as file:
    reader = csv.DictReader(file)
    for row in reader:
        print(row["language"])
