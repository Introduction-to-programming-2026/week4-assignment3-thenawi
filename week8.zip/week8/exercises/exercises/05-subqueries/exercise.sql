-- Exercise 05: Subqueries
-- Databases: school.db and library.db

.headers on
.mode column

-- 5.1: Students with GPA above the average (school.db)
SELECT first_name, last_name, gpa
FROM students
WHERE gpa > (SELECT AVG(gpa) FROM students)
ORDER BY gpa DESC;

-- 5.2: Students enrolled in CS50 (use subquery) (school.db)
SELECT first_name, last_name
FROM students
WHERE id IN (
    SELECT student_id
    FROM enrollments
    WHERE course_id = (
        SELECT id FROM courses WHERE code = 'CS50'
    )
)
ORDER BY last_name, first_name;

-- 5.3: Students NOT enrolled in CS50 (school.db)
SELECT first_name, last_name
FROM students
WHERE id NOT IN (
    SELECT student_id
    FROM enrollments
    WHERE course_id = (
        SELECT id FROM courses WHERE code = 'CS50'
    )
)
ORDER BY last_name, first_name;

-- 5.4: Courses taught by the highest-paid teacher (school.db)
SELECT code, title
FROM courses
WHERE teacher_id IN (
    SELECT id
    FROM teachers
    WHERE salary = (SELECT MAX(salary) FROM teachers)
);

-- 5.5: Students enrolled in 3 or more courses (subquery in FROM) (school.db)
SELECT s.first_name,
       s.last_name,
       enrollment_counts.course_count
FROM (
    SELECT student_id, COUNT(*) AS course_count
    FROM enrollments
    GROUP BY student_id
) AS enrollment_counts
JOIN students s ON s.id = enrollment_counts.student_id
WHERE enrollment_counts.course_count >= 3
ORDER BY enrollment_counts.course_count DESC, s.last_name;

-- 5.6: Members who borrowed more than 2 books (library.db)
SELECT first_name, last_name
FROM members
WHERE id IN (
    SELECT member_id
    FROM loans
    GROUP BY member_id
    HAVING COUNT(*) > 2
)
ORDER BY last_name, first_name;

-- 5.7: Books with more pages than average (library.db)
SELECT title, pages
FROM books
WHERE pages > (SELECT AVG(pages) FROM books)
ORDER BY pages DESC;

-- 5.8: Students with at least one grade (EXISTS) (school.db)
SELECT s.first_name, s.last_name
FROM students s
WHERE EXISTS (
    SELECT 1
    FROM enrollments e
    JOIN grades g ON g.enrollment_id = e.id
    WHERE e.student_id = s.id
      AND g.letter_grade IS NOT NULL
)
ORDER BY s.last_name, s.first_name;

-- 5.9: Courses with no grades recorded (NOT EXISTS) (school.db)
SELECT c.code, c.title
FROM courses c
WHERE NOT EXISTS (
    SELECT 1
    FROM enrollments e
    JOIN grades g ON g.enrollment_id = e.id
    WHERE e.course_id = c.id
      AND g.letter_grade IS NOT NULL
)
ORDER BY c.code;

-- 5.10 CHALLENGE: Course(s) with the most enrollments (no LIMIT) (school.db)
SELECT counts.code,
       counts.title,
       counts.enrollment_count
FROM (
    SELECT c.id,
           c.code,
           c.title,
           COUNT(e.id) AS enrollment_count
    FROM courses c
    LEFT JOIN enrollments e ON e.course_id = c.id
    GROUP BY c.id
) AS counts
WHERE counts.enrollment_count = (
    SELECT MAX(course_count)
    FROM (
        SELECT COUNT(*) AS course_count
        FROM enrollments
        GROUP BY course_id
    )
)
ORDER BY counts.code;
