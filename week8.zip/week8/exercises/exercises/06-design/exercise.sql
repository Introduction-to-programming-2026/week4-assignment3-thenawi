-- Exercise 06: Database Design
-- Create a new database file for each exercise:
-- sqlite3 data/social.db < exercises/06-design/exercise.sql

-- ============================================================
-- 6.1 - Social Media Schema
-- ============================================================
-- Design entities: Users, Posts, Follows, Likes, Comments
-- Write your CREATE TABLE statements below:

DROP TABLE IF EXISTS comments;
DROP TABLE IF EXISTS likes;
DROP TABLE IF EXISTS follows;
DROP TABLE IF EXISTS posts;
DROP TABLE IF EXISTS users;

CREATE TABLE users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL UNIQUE,
    email TEXT NOT NULL UNIQUE,
    bio TEXT DEFAULT '',
    joined_at TEXT NOT NULL
);

CREATE TABLE posts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id)
);

CREATE TABLE follows (
    follower_id INTEGER NOT NULL,
    followed_id INTEGER NOT NULL,
    followed_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (follower_id, followed_id),
    CHECK (follower_id <> followed_id),
    FOREIGN KEY (follower_id) REFERENCES users(id),
    FOREIGN KEY (followed_id) REFERENCES users(id)
);

CREATE TABLE likes (
    user_id INTEGER NOT NULL,
    post_id INTEGER NOT NULL,
    liked_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    PRIMARY KEY (user_id, post_id),
    FOREIGN KEY (user_id) REFERENCES users(id),
    FOREIGN KEY (post_id) REFERENCES posts(id)
);

CREATE TABLE comments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    post_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    content TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (post_id) REFERENCES posts(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);

-- ============================================================
-- 6.2 - Movie Rental Schema
-- ============================================================
-- Entities: Genres, Movies, Copies, Customers, Rentals, Reviews
-- Write your CREATE TABLE statements below:

DROP TABLE IF EXISTS movie_reviews;
DROP TABLE IF EXISTS rentals;
DROP TABLE IF EXISTS customers;
DROP TABLE IF EXISTS copies;
DROP TABLE IF EXISTS movies;
DROP TABLE IF EXISTS movie_genres;

CREATE TABLE movie_genres (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE
);

CREATE TABLE movies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    title TEXT NOT NULL,
    release_year INTEGER,
    rating TEXT NOT NULL CHECK (rating IN ('G', 'PG', 'PG-13', 'R')),
    genre_id INTEGER NOT NULL,
    FOREIGN KEY (genre_id) REFERENCES movie_genres(id)
);

CREATE TABLE copies (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    movie_id INTEGER NOT NULL,
    condition TEXT NOT NULL CHECK (condition IN ('good', 'fair', 'damaged')),
    status TEXT NOT NULL DEFAULT 'available' CHECK (status IN ('available', 'rented')),
    FOREIGN KEY (movie_id) REFERENCES movies(id)
);

CREATE TABLE customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT
);

CREATE TABLE rentals (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    copy_id INTEGER NOT NULL,
    customer_id INTEGER NOT NULL,
    rental_date TEXT NOT NULL,
    due_date TEXT NOT NULL,
    return_date TEXT,
    FOREIGN KEY (copy_id) REFERENCES copies(id),
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

CREATE TABLE movie_reviews (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    movie_id INTEGER NOT NULL,
    customer_id INTEGER NOT NULL,
    stars INTEGER NOT NULL CHECK (stars BETWEEN 1 AND 5),
    review_text TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE (movie_id, customer_id),
    FOREIGN KEY (movie_id) REFERENCES movies(id),
    FOREIGN KEY (customer_id) REFERENCES customers(id)
);

-- ============================================================
-- 6.3 - E-Commerce Schema
-- ============================================================
-- Entities: Categories, Products, Customers, Orders, OrderItems
-- Write your CREATE TABLE statements below:

DROP TABLE IF EXISTS order_items;
DROP TABLE IF EXISTS orders;
DROP TABLE IF EXISTS shop_customers;
DROP TABLE IF EXISTS products;
DROP TABLE IF EXISTS categories;

CREATE TABLE categories (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL UNIQUE,
    parent_category_id INTEGER,
    FOREIGN KEY (parent_category_id) REFERENCES categories(id)
);

CREATE TABLE products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    description TEXT,
    price REAL NOT NULL CHECK (price >= 0),
    stock_count INTEGER NOT NULL DEFAULT 0 CHECK (stock_count >= 0),
    FOREIGN KEY (category_id) REFERENCES categories(id)
);

CREATE TABLE shop_customers (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    full_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    phone TEXT
);

CREATE TABLE orders (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    customer_id INTEGER NOT NULL,
    order_date TEXT NOT NULL,
    status TEXT NOT NULL CHECK (status IN ('pending', 'shipped', 'delivered', 'cancelled')),
    FOREIGN KEY (customer_id) REFERENCES shop_customers(id)
);

CREATE TABLE order_items (
    order_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    quantity INTEGER NOT NULL CHECK (quantity > 0),
    unit_price REAL NOT NULL CHECK (unit_price >= 0),
    PRIMARY KEY (order_id, product_id),
    FOREIGN KEY (order_id) REFERENCES orders(id),
    FOREIGN KEY (product_id) REFERENCES products(id)
);

-- ============================================================
-- 6.4 - Fix the Bad Schema
-- ============================================================
-- What's wrong with this? Write your fixed version:
--
-- CREATE TABLE student_data (
--     info TEXT,
--     name_and_email TEXT,
--     courses TEXT,
--     gpa TEXT,
--     teacher_name TEXT,
--     teacher_salary TEXT
-- );
--
-- Problems identified:
-- 1. No primary key.
-- 2. Combined columns like name_and_email are not atomic (violates 1NF).
-- 3. courses stores multiple values in one field.
-- 4. gpa and teacher_salary are stored as TEXT, not numeric.
-- 5. Teacher data is duplicated in student rows (update anomalies).
-- 6. No foreign keys / relationship structure.
-- Fixed schema:

DROP TABLE IF EXISTS enrollments_clean;
DROP TABLE IF EXISTS courses_clean;
DROP TABLE IF EXISTS teachers_clean;
DROP TABLE IF EXISTS students_clean;

CREATE TABLE students_clean (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    email TEXT NOT NULL UNIQUE,
    gpa REAL CHECK (gpa BETWEEN 0 AND 4)
);

CREATE TABLE teachers_clean (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    first_name TEXT NOT NULL,
    last_name TEXT NOT NULL,
    salary REAL NOT NULL CHECK (salary >= 0)
);

CREATE TABLE courses_clean (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    code TEXT NOT NULL UNIQUE,
    title TEXT NOT NULL,
    teacher_id INTEGER,
    FOREIGN KEY (teacher_id) REFERENCES teachers_clean(id)
);

CREATE TABLE enrollments_clean (
    student_id INTEGER NOT NULL,
    course_id INTEGER NOT NULL,
    PRIMARY KEY (student_id, course_id),
    FOREIGN KEY (student_id) REFERENCES students_clean(id),
    FOREIGN KEY (course_id) REFERENCES courses_clean(id)
);

-- ============================================================
-- 6.5 - Seed Your Social Media Database
-- ============================================================
-- After creating tables in 6.1, insert sample data:

INSERT INTO users (username, email, bio, joined_at) VALUES
    ('alice', 'alice@example.com', 'Loves data and books', '2024-01-10'),
    ('bob', 'bob@example.com', 'Backend learner', '2024-01-12'),
    ('carol', 'carol@example.com', 'Front-end enthusiast', '2024-01-20'),
    ('dave', 'dave@example.com', 'CS student', '2024-02-01'),
    ('eve', 'eve@example.com', 'Security curious', '2024-02-10');

INSERT INTO posts (user_id, content, created_at) VALUES
    (1, 'Starting SQL today.', '2024-03-01 10:00:00'),
    (2, 'Python dictionaries are great.', '2024-03-01 10:20:00'),
    (3, 'Built my first CSS layout!', '2024-03-01 11:00:00'),
    (4, 'Debugging Flask routes now.', '2024-03-01 12:00:00'),
    (5, 'Trying CTF challenges this weekend.', '2024-03-01 13:00:00'),
    (1, 'JOIN queries finally clicked.', '2024-03-02 09:00:00'),
    (2, 'I like clean commit history.', '2024-03-02 10:00:00'),
    (3, 'Responsive design practice day.', '2024-03-02 11:00:00'),
    (4, 'SQLite is fast for prototypes.', '2024-03-02 12:00:00'),
    (5, 'Session handling can be tricky.', '2024-03-02 13:00:00');

INSERT INTO follows (follower_id, followed_id) VALUES
    (1, 2),
    (1, 3),
    (2, 1),
    (3, 1),
    (4, 1),
    (5, 4);

INSERT INTO likes (user_id, post_id) VALUES
    (1, 2),
    (1, 4),
    (2, 1),
    (2, 6),
    (3, 1),
    (3, 8),
    (4, 3),
    (4, 9),
    (5, 5),
    (5, 10);

INSERT INTO comments (post_id, user_id, content, created_at) VALUES
    (1, 2, 'Nice start!', '2024-03-01 10:05:00'),
    (2, 1, 'Totally agree.', '2024-03-01 10:25:00'),
    (3, 4, 'Show us screenshots.', '2024-03-01 11:10:00'),
    (4, 5, 'Check method decorators.', '2024-03-01 12:10:00'),
    (6, 3, 'Same here, joins were hard.', '2024-03-02 09:10:00');

-- Verification queries:
-- Q1: Who does user 1 follow?
SELECT u2.username AS followed_user
FROM follows f
JOIN users u2 ON u2.id = f.followed_id
WHERE f.follower_id = 1;

-- Q2: Most liked posts?
SELECT p.id,
       p.content,
       COUNT(l.user_id) AS like_count
FROM posts p
LEFT JOIN likes l ON l.post_id = p.id
GROUP BY p.id
ORDER BY like_count DESC, p.id;

-- Q3: User who posted the most?
SELECT u.username,
       COUNT(p.id) AS post_count
FROM users u
LEFT JOIN posts p ON p.user_id = u.id
GROUP BY u.id
ORDER BY post_count DESC, u.username;
