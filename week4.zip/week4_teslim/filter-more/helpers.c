#include "helpers.h"
#include <math.h>
#include <string.h>

void grayscale(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int average = (int) round((image[i][j].rgbtRed + image[i][j].rgbtGreen + image[i][j].rgbtBlue) / 3.0);
            image[i][j].rgbtRed = average;
            image[i][j].rgbtGreen = average;
            image[i][j].rgbtBlue = average;
        }
    }
}

void reflect(int height, int width, RGBTRIPLE image[height][width])
{
    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width / 2; j++)
        {
            RGBTRIPLE temp = image[i][j];
            image[i][j] = image[i][width - 1 - j];
            image[i][width - 1 - j] = temp;
        }
    }
}

void blur(int height, int width, RGBTRIPLE image[height][width])
{
    RGBTRIPLE copy[height][width];
    memcpy(copy, image, sizeof(copy));

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int sum_red = 0;
            int sum_green = 0;
            int sum_blue = 0;
            int count = 0;

            for (int di = -1; di <= 1; di++)
            {
                for (int dj = -1; dj <= 1; dj++)
                {
                    int ni = i + di;
                    int nj = j + dj;

                    if (ni >= 0 && ni < height && nj >= 0 && nj < width)
                    {
                        sum_red += copy[ni][nj].rgbtRed;
                        sum_green += copy[ni][nj].rgbtGreen;
                        sum_blue += copy[ni][nj].rgbtBlue;
                        count++;
                    }
                }
            }

            image[i][j].rgbtRed = (int) round((float) sum_red / count);
            image[i][j].rgbtGreen = (int) round((float) sum_green / count);
            image[i][j].rgbtBlue = (int) round((float) sum_blue / count);
        }
    }
}

void edges(int height, int width, RGBTRIPLE image[height][width])
{
    int Gx[3][3] = {
        {-1, 0, 1},
        {-2, 0, 2},
        {-1, 0, 1}
    };

    int Gy[3][3] = {
        {-1, -2, -1},
        {0, 0, 0},
        {1, 2, 1}
    };

    RGBTRIPLE copy[height][width];
    memcpy(copy, image, sizeof(copy));

    for (int i = 0; i < height; i++)
    {
        for (int j = 0; j < width; j++)
        {
            int gx_red = 0;
            int gy_red = 0;
            int gx_green = 0;
            int gy_green = 0;
            int gx_blue = 0;
            int gy_blue = 0;

            for (int di = -1; di <= 1; di++)
            {
                for (int dj = -1; dj <= 1; dj++)
                {
                    int ni = i + di;
                    int nj = j + dj;

                    if (ni < 0 || ni >= height || nj < 0 || nj >= width)
                    {
                        continue;
                    }

                    int weight_x = Gx[di + 1][dj + 1];
                    int weight_y = Gy[di + 1][dj + 1];

                    gx_red += copy[ni][nj].rgbtRed * weight_x;
                    gy_red += copy[ni][nj].rgbtRed * weight_y;

                    gx_green += copy[ni][nj].rgbtGreen * weight_x;
                    gy_green += copy[ni][nj].rgbtGreen * weight_y;

                    gx_blue += copy[ni][nj].rgbtBlue * weight_x;
                    gy_blue += copy[ni][nj].rgbtBlue * weight_y;
                }
            }

            int red = (int) round(sqrt(gx_red * gx_red + gy_red * gy_red));
            int green = (int) round(sqrt(gx_green * gx_green + gy_green * gy_green));
            int blue = (int) round(sqrt(gx_blue * gx_blue + gy_blue * gy_blue));

            image[i][j].rgbtRed = red > 255 ? 255 : red;
            image[i][j].rgbtGreen = green > 255 ? 255 : green;
            image[i][j].rgbtBlue = blue > 255 ? 255 : blue;
        }
    }
}
