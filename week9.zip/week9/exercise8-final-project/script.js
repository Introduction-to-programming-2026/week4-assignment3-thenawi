const form = document.querySelector('#search-form');
const cityInput = document.querySelector('#city-input');
const statusMessage = document.querySelector('#status-message');
const cityTitle = document.querySelector('#city-title');
const cityMeta = document.querySelector('#city-meta');
const currentCard = document.querySelector('#current-card');
const forecastGrid = document.querySelector('#forecast-grid');
const recentChips = document.querySelector('#recent-chips');
const unitToggle = document.querySelector('#unit-toggle');

const STORAGE_KEY = 'week9_weather_recent_cities';
let weatherState = null;
let useFahrenheit = false;

const weatherLabels = {
  0: { icon: 'Sunny', text: 'Clear sky' },
  1: { icon: 'Mostly sunny', text: 'Mainly clear' },
  2: { icon: 'Partly cloudy', text: 'Partly cloudy' },
  3: { icon: 'Cloudy', text: 'Overcast' },
  45: { icon: 'Fog', text: 'Fog' },
  48: { icon: 'Fog', text: 'Depositing rime fog' },
  51: { icon: 'Drizzle', text: 'Light drizzle' },
  53: { icon: 'Drizzle', text: 'Moderate drizzle' },
  55: { icon: 'Drizzle', text: 'Dense drizzle' },
  61: { icon: 'Rain', text: 'Slight rain' },
  63: { icon: 'Rain', text: 'Moderate rain' },
  65: { icon: 'Rain', text: 'Heavy rain' },
  71: { icon: 'Snow', text: 'Slight snow fall' },
  73: { icon: 'Snow', text: 'Moderate snow fall' },
  75: { icon: 'Snow', text: 'Heavy snow fall' },
  95: { icon: 'Storm', text: 'Thunderstorm' },
};

function getLabel(code) {
  return weatherLabels[code] || { icon: 'Weather', text: 'Conditions unavailable' };
}

function cToF(value) {
  return (value * 9) / 5 + 32;
}

function formatTemp(valueCelsius) {
  const value = useFahrenheit ? cToF(valueCelsius) : valueCelsius;
  const unit = useFahrenheit ? 'F' : 'C';
  return `${value.toFixed(1)}${unit}`;
}

function setStatus(message, isError = false) {
  statusMessage.textContent = message;
  statusMessage.style.color = isError ? '#a63d20' : '#5f6f76';
}

function loadRecentCities() {
  return JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
}

function saveRecentCities(cities) {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(cities));
}

function rememberCity(city) {
  const cities = loadRecentCities().filter((item) => item.toLowerCase() !== city.toLowerCase());
  cities.unshift(city);
  saveRecentCities(cities.slice(0, 6));
  renderRecentChips();
}

function renderRecentChips() {
  const cities = loadRecentCities();
  recentChips.innerHTML = '';

  if (cities.length === 0) {
    recentChips.innerHTML = '<p>No recent searches yet.</p>';
    return;
  }

  cities.forEach((city) => {
    const button = document.createElement('button');
    button.type = 'button';
    button.className = 'recent-chip';
    button.textContent = city;
    button.addEventListener('click', () => searchCity(city));
    recentChips.appendChild(button);
  });
}

function renderWeather() {
  if (!weatherState) {
    return;
  }

  const { locationName, locationMeta, current, daily } = weatherState;
  const currentLabel = getLabel(current.weathercode);

  cityTitle.textContent = locationName;
  cityMeta.textContent = locationMeta;
  unitToggle.textContent = useFahrenheit ? 'Switch to Celsius' : 'Switch to Fahrenheit';

  currentCard.innerHTML = `
    <div class="current-card__top">
      <div>
        <p class="current-card__temp">${formatTemp(current.temperature)}</p>
        <p class="current-card__code">${currentLabel.icon} - ${currentLabel.text}</p>
      </div>
      <div>
        <p>Wind: ${current.windspeed} km/h</p>
        <p>Time: ${current.time}</p>
      </div>
    </div>
  `;
  currentCard.classList.remove('hidden');

  forecastGrid.innerHTML = '';
  daily.time.forEach((date, index) => {
    const dayLabel = new Date(date).toLocaleDateString('en-US', { weekday: 'short' });
    const details = getLabel(daily.weathercode[index]);

    const card = document.createElement('article');
    card.className = 'forecast-item';
    card.innerHTML = `
      <p class="day">${dayLabel}</p>
      <p>${details.icon}</p>
      <p>High: ${formatTemp(daily.temperature_2m_max[index])}</p>
      <p>Low: ${formatTemp(daily.temperature_2m_min[index])}</p>
    `;
    forecastGrid.appendChild(card);
  });
}

async function fetchWeather(latitude, longitude, locationName, locationMeta) {
  const params = new URLSearchParams({
    latitude: String(latitude),
    longitude: String(longitude),
    daily: 'temperature_2m_max,temperature_2m_min,weathercode',
    current_weather: 'true',
    timezone: 'auto',
  });

  const response = await fetch(`https://api.open-meteo.com/v1/forecast?${params.toString()}`);
  if (!response.ok) {
    throw new Error('Weather API request failed.');
  }

  const data = await response.json();
  weatherState = {
    locationName,
    locationMeta,
    current: data.current_weather,
    daily: data.daily,
  };

  renderWeather();
}

async function searchCity(cityName) {
  const query = cityName.trim();
  if (!query) {
    setStatus('Please enter a city name.', true);
    return;
  }

  setStatus('Loading weather...');

  try {
    const geocodeUrl = `https://geocoding-api.open-meteo.com/v1/search?name=${encodeURIComponent(query)}&count=1`;
    const geoResponse = await fetch(geocodeUrl);

    if (!geoResponse.ok) {
      throw new Error('City search failed.');
    }

    const geoData = await geoResponse.json();
    if (!geoData.results || geoData.results.length === 0) {
      throw new Error('City not found.');
    }

    const location = geoData.results[0];
    const name = `${location.name}${location.country ? `, ${location.country}` : ''}`;
    const meta = `Latitude ${location.latitude.toFixed(2)}, Longitude ${location.longitude.toFixed(2)}`;

    await fetchWeather(location.latitude, location.longitude, name, meta);
    rememberCity(location.name);
    setStatus('');
  } catch (error) {
    setStatus(error.message || 'Something went wrong.', true);
  }
}

form.addEventListener('submit', async (event) => {
  event.preventDefault();
  await searchCity(cityInput.value);
});

unitToggle.addEventListener('click', () => {
  if (!weatherState) {
    return;
  }

  useFahrenheit = !useFahrenheit;
  renderWeather();
});

renderRecentChips();
const initialCities = loadRecentCities();
if (initialCities.length > 0) {
  searchCity(initialCities[0]);
}
