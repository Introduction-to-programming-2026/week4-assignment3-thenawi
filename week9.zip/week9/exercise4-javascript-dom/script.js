/**
 * Exercise 4: JavaScript & the DOM
 */

const mainTitle = document.querySelector('#main-title');
mainTitle.textContent = 'DOM Mastery';

const cards = document.querySelectorAll('.card');
console.log(`Card count: ${cards.length}`);

const targetBox = document.querySelector('#target-box');
targetBox.style.backgroundColor = '#e8f6ff';

const countDisplay = document.querySelector('#count-display');
const incrementBtn = document.querySelector('#btn-increment');
const decrementBtn = document.querySelector('#btn-decrement');
const resetBtn = document.querySelector('#btn-reset');

let count = 0;

function updateCountDisplay() {
  countDisplay.textContent = count;

  if (count === 0) {
    countDisplay.classList.add('zero');
    countDisplay.classList.remove('high');
  } else if (count > 5) {
    countDisplay.classList.add('high');
    countDisplay.classList.remove('zero');
  } else {
    countDisplay.classList.remove('zero', 'high');
  }
}

incrementBtn.addEventListener('click', function() {
  count += 1;
  updateCountDisplay();
});

decrementBtn.addEventListener('click', function() {
  if (count > 0) {
    count -= 1;
    updateCountDisplay();
  }
});

resetBtn.addEventListener('click', function() {
  count = 0;
  updateCountDisplay();
});

updateCountDisplay();

const listInput = document.querySelector('#list-input');
const dynamicList = document.querySelector('#dynamic-list');
const addItemBtn = document.querySelector('#btn-add-item');

addItemBtn.addEventListener('click', function() {
  const value = listInput.value.trim();
  if (!value) {
    listInput.classList.add('shake');
    setTimeout(function() {
      listInput.classList.remove('shake');
    }, 300);
    listInput.focus();
    return;
  }

  const li = document.createElement('li');
  li.textContent = value + ' ';

  const deleteButton = document.createElement('button');
  deleteButton.textContent = 'x';
  deleteButton.className = 'delete-btn';

  li.appendChild(deleteButton);
  dynamicList.appendChild(li);

  listInput.value = '';
  listInput.focus();
});

dynamicList.addEventListener('click', function(event) {
  if (event.target.classList.contains('delete-btn')) {
    event.target.parentElement.remove();
  }
});

const toggleBtn = document.querySelector('#btn-toggle');
const detailsDiv = document.querySelector('.details');

toggleBtn.addEventListener('click', function() {
  detailsDiv.classList.toggle('hidden');
  toggleBtn.textContent = detailsDiv.classList.contains('hidden')
    ? 'Show Details'
    : 'Hide Details';
});

const sliderR = document.querySelector('#slider-r');
const sliderG = document.querySelector('#slider-g');
const sliderB = document.querySelector('#slider-b');
const colorPreview = document.querySelector('#color-preview');
const hexDisplay = document.querySelector('#hex-display');

function updateColor() {
  const r = parseInt(sliderR.value);
  const g = parseInt(sliderG.value);
  const b = parseInt(sliderB.value);

  document.querySelector('#val-r').textContent = r;
  document.querySelector('#val-g').textContent = g;
  document.querySelector('#val-b').textContent = b;

  colorPreview.style.backgroundColor = `rgb(${r}, ${g}, ${b})`;

  const rHex = r.toString(16).padStart(2, '0');
  const gHex = g.toString(16).padStart(2, '0');
  const bHex = b.toString(16).padStart(2, '0');
  hexDisplay.textContent = `#${rHex}${gHex}${bHex}`.toUpperCase();
}

sliderR.addEventListener('input', updateColor);
sliderG.addEventListener('input', updateColor);
sliderB.addEventListener('input', updateColor);

updateColor();
