/**
 * Exercise 6: Fetch & APIs
 */

function showLoading(element) {
  element.innerHTML = '<div class="spinner"></div>';
}

function showError(element, message) {
  element.innerHTML = `<p class="error-text">${message}</p>`;
}

const quoteDisplay = document.querySelector('#quote-display');
const btnNewQuote = document.querySelector('#btn-new-quote');

async function fetchQuote() {
  showLoading(quoteDisplay);

  try {
    const response = await fetch('https://api.quotable.io/random');
    if (!response.ok) {
      throw new Error('Quote service unavailable');
    }

    const data = await response.json();
    quoteDisplay.innerHTML = `
      <blockquote>"${data.content}"</blockquote>
      <p class="quote-author">- ${data.author}</p>
    `;
  } catch (error) {
    showError(quoteDisplay, 'Could not load quote. Check your connection.');
    console.error(error);
  }
}

fetchQuote();
btnNewQuote.addEventListener('click', fetchQuote);

const githubInput = document.querySelector('#github-input');
const btnSearch = document.querySelector('#btn-search-user');
const githubResult = document.querySelector('#github-result');

async function searchUser() {
  const username = githubInput.value.trim();
  if (!username) {
    return;
  }

  showLoading(githubResult);

  try {
    const response = await fetch(`https://api.github.com/users/${username}`);

    if (response.status === 404) {
      showError(githubResult, 'User not found.');
      return;
    }

    if (!response.ok) {
      throw new Error('GitHub request failed.');
    }

    const user = await response.json();
    githubResult.innerHTML = `
      <div class="github-card">
        <img src="${user.avatar_url}" alt="${user.login} avatar" />
        <div class="github-info">
          <h3>${user.name || user.login}</h3>
          <p>@${user.login}</p>
          <p>${user.bio || 'No bio provided.'}</p>
          <div class="github-stats">
            <span>Followers: ${user.followers}</span>
            <span>Repos: ${user.public_repos}</span>
          </div>
          <p><a href="${user.html_url}" target="_blank" rel="noopener noreferrer">Open profile</a></p>
        </div>
      </div>
    `;
  } catch (error) {
    showError(githubResult, error.message || 'Search failed. Try again.');
  }
}

btnSearch.addEventListener('click', searchUser);
githubInput.addEventListener('keydown', (event) => {
  if (event.key === 'Enter') {
    searchUser();
  }
});

const postsContainer = document.querySelector('#posts-container');
const btnLoadMore = document.querySelector('#btn-load-more');
let currentPage = 1;
const postsPerPage = 10;

async function loadPosts() {
  btnLoadMore.disabled = true;
  const start = (currentPage - 1) * postsPerPage;

  try {
    const response = await fetch(
      `https://jsonplaceholder.typicode.com/posts?_start=${start}&_limit=${postsPerPage}`
    );

    if (!response.ok) {
      throw new Error('Could not load posts.');
    }

    const posts = await response.json();

    if (posts.length === 0) {
      btnLoadMore.textContent = 'No More Posts';
      return;
    }

    posts.forEach(function(post) {
      const card = document.createElement('article');
      card.className = 'post-card';
      card.dataset.postId = String(post.id);
      card.innerHTML = `
        <h3>${post.title}</h3>
        <p>${post.body}</p>
      `;

      card.addEventListener('click', function() {
        loadComments(post.id, card);
      });

      postsContainer.appendChild(card);
    });

    currentPage += 1;
  } catch (error) {
    showError(postsContainer, error.message || 'Loading posts failed.');
  } finally {
    if (btnLoadMore.textContent !== 'No More Posts') {
      btnLoadMore.disabled = false;
    }
  }
}

async function loadComments(postId, cardElement) {
  const existing = cardElement.querySelector('.comments-list');
  if (existing) {
    existing.remove();
    return;
  }

  try {
    const response = await fetch(`https://jsonplaceholder.typicode.com/posts/${postId}/comments`);
    if (!response.ok) {
      throw new Error('Could not load comments.');
    }

    const comments = await response.json();
    const list = document.createElement('div');
    list.className = 'comments-list';

    comments.slice(0, 4).forEach(function(comment) {
      const item = document.createElement('div');
      item.className = 'comment';
      item.innerHTML = `<strong>${comment.email}</strong><br>${comment.body}`;
      list.appendChild(item);
    });

    cardElement.appendChild(list);
  } catch (error) {
    const errorItem = document.createElement('div');
    errorItem.className = 'comment';
    errorItem.textContent = 'Unable to load comments.';
    cardElement.appendChild(errorItem);
  }
}

loadPosts();
btnLoadMore.addEventListener('click', loadPosts);

const btnFetchAll = document.querySelector('#btn-fetch-all');
const multiResult = document.querySelector('#multi-result');

async function fetchAllParallel() {
  showLoading(multiResult);

  try {
    const [quoteRes, userRes, todoRes] = await Promise.all([
      fetch('https://api.quotable.io/random'),
      fetch('https://jsonplaceholder.typicode.com/users/1'),
      fetch('https://jsonplaceholder.typicode.com/todos/1'),
    ]);

    if (!quoteRes.ok || !userRes.ok || !todoRes.ok) {
      throw new Error('At least one request failed.');
    }

    const [quote, user, todo] = await Promise.all([
      quoteRes.json(),
      userRes.json(),
      todoRes.json(),
    ]);

    multiResult.innerHTML = `
      <div class="multi-grid">
        <article class="multi-card">
          <h4>Quote</h4>
          <p>"${quote.content}"</p>
        </article>
        <article class="multi-card">
          <h4>User</h4>
          <p>${user.name} (${user.email})</p>
        </article>
        <article class="multi-card">
          <h4>Todo</h4>
          <p>${todo.title}</p>
          <p>Status: ${todo.completed ? 'Completed' : 'Pending'}</p>
        </article>
      </div>
    `;
  } catch (error) {
    showError(multiResult, 'One or more requests failed.');
  }
}

btnFetchAll.addEventListener('click', fetchAllParallel);
