/**
 * Exercise 7: Local Storage - Notes App
 */

const STORAGE_KEY = 'week9_notes';

let notes = JSON.parse(localStorage.getItem(STORAGE_KEY) || '[]');
let editingId = null;

function saveNotes() {
  localStorage.setItem(STORAGE_KEY, JSON.stringify(notes));
}

const notesContainer = document.querySelector('#notes-container');
const notesCount = document.querySelector('#notes-count');

function formatDate(iso) {
  return new Date(iso).toLocaleDateString('en-US', {
    month: 'short',
    day: 'numeric',
    year: 'numeric',
  });
}

function renderNotes(filter = '') {
  notesContainer.innerHTML = '';

  let filtered = notes;
  if (filter.trim()) {
    const term = filter.trim().toLowerCase();
    filtered = notes.filter(function(note) {
      return (
        note.title.toLowerCase().includes(term) ||
        note.body.toLowerCase().includes(term)
      );
    });
  }

  filtered = [...filtered].sort(function(a, b) {
    if (a.pinned === b.pinned) {
      return b.id - a.id;
    }
    return a.pinned ? -1 : 1;
  });

  notesCount.textContent = `${filtered.length} shown / ${notes.length} total`;

  if (filtered.length === 0) {
    notesContainer.innerHTML = `
      <div class="empty-state">
        <p>${filter ? `No results for "${filter}"` : 'No notes yet. Create your first one!'}</p>
      </div>`;
    return;
  }

  filtered.forEach(function(note) {
    const preview = note.body.length > 100 ? `${note.body.slice(0, 100)}...` : note.body;
    const card = document.createElement('article');
    card.className = `note-card${note.pinned ? ' pinned' : ''}`;

    card.innerHTML = `
      <h3>${note.pinned ? 'Pinned ' : ''}${note.title}</h3>
      <p class="note-body">${preview || 'No details.'}</p>
      <div class="note-meta">
        <span>${formatDate(note.createdAt)}</span>
        <div class="note-actions">
          <button class="btn-edit" data-action="edit" data-id="${note.id}">Edit</button>
          <button class="btn-pin" data-action="pin" data-id="${note.id}">${note.pinned ? 'Unpin' : 'Pin'}</button>
          <button class="btn-delete" data-action="delete" data-id="${note.id}">Delete</button>
        </div>
      </div>
    `;

    notesContainer.appendChild(card);
  });
}

const noteForm = document.querySelector('#note-form');
const titleInput = document.querySelector('#note-title');
const bodyInput = document.querySelector('#note-body');
const submitBtn = document.querySelector('#btn-submit');
const cancelBtn = document.querySelector('#btn-cancel');
const formTitle = document.querySelector('#form-title');

function setFormMode(isEditing) {
  if (isEditing) {
    formTitle.textContent = 'Edit Note';
    submitBtn.textContent = 'Update Note';
    cancelBtn.classList.remove('hidden');
  } else {
    formTitle.textContent = 'New Note';
    submitBtn.textContent = 'Save Note';
    cancelBtn.classList.add('hidden');
  }
}

noteForm.addEventListener('submit', function(event) {
  event.preventDefault();

  const title = titleInput.value.trim();
  const body = bodyInput.value.trim();

  if (!title) {
    titleInput.focus();
    return;
  }

  if (editingId !== null) {
    const note = notes.find(function(item) {
      return item.id === editingId;
    });

    if (note) {
      note.title = title;
      note.body = body;
    }

    editingId = null;
    setFormMode(false);
  } else {
    const note = {
      id: Date.now(),
      title,
      body,
      createdAt: new Date().toISOString(),
      pinned: false,
    };

    notes.push(note);
  }

  saveNotes();
  renderNotes(searchInput.value);
  noteForm.reset();
});

cancelBtn.addEventListener('click', function() {
  editingId = null;
  noteForm.reset();
  setFormMode(false);
});

notesContainer.addEventListener('click', function(event) {
  const button = event.target.closest('button[data-action]');
  if (!button) {
    return;
  }

  const id = Number(button.dataset.id);
  const action = button.dataset.action;

  if (action === 'delete') {
    const confirmed = confirm('Delete this note?');
    if (!confirmed) {
      return;
    }

    notes = notes.filter(function(note) {
      return note.id !== id;
    });
    saveNotes();
    renderNotes(searchInput.value);
  }

  if (action === 'pin') {
    const note = notes.find(function(item) {
      return item.id === id;
    });
    if (!note) {
      return;
    }

    note.pinned = !note.pinned;
    saveNotes();
    renderNotes(searchInput.value);
  }

  if (action === 'edit') {
    const note = notes.find(function(item) {
      return item.id === id;
    });
    if (!note) {
      return;
    }

    editingId = note.id;
    titleInput.value = note.title;
    bodyInput.value = note.body;
    setFormMode(true);
    titleInput.focus();
  }
});

const searchInput = document.querySelector('#search-input');
searchInput.addEventListener('input', function() {
  renderNotes(searchInput.value);
});

setFormMode(false);
renderNotes();
