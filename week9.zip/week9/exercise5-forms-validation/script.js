/**
 * Exercise 5: Forms & Validation
 */

const form = document.querySelector('#registration-form');
const submitButton = document.querySelector('#submit-btn');

function showError(inputId, message) {
  const input = document.querySelector(`#${inputId}`);
  const error = document.querySelector(`#error-${inputId}`);

  if (input) {
    input.classList.remove('valid');
    input.classList.add('invalid');
  }
  if (error) {
    error.textContent = message;
  }
}

function clearError(inputId) {
  const input = document.querySelector(`#${inputId}`);
  const error = document.querySelector(`#error-${inputId}`);

  if (input) {
    input.classList.remove('invalid');
    input.classList.add('valid');
  }
  if (error) {
    error.textContent = '';
  }
}

function validateName() {
  const value = document.querySelector('#full-name').value.trim();
  if (value.length < 2) {
    showError('full-name', 'Name must be at least 2 characters.');
    return false;
  }
  clearError('full-name');
  return true;
}

function validateEmail() {
  const value = document.querySelector('#email').value.trim();
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
  if (!emailPattern.test(value)) {
    showError('email', 'Enter a valid email address.');
    return false;
  }
  clearError('email');
  return true;
}

function validatePassword() {
  const value = document.querySelector('#password').value;
  const hasDigit = /\d/.test(value);

  updatePasswordStrength(value);

  if (value.length < 8 || !hasDigit) {
    showError('password', 'Password must be 8+ chars and include a number.');
    return false;
  }
  clearError('password');
  return true;
}

function validateConfirmPassword() {
  const password = document.querySelector('#password').value;
  const confirm = document.querySelector('#confirm-password').value;
  if (password !== confirm || confirm.length === 0) {
    showError('confirm-password', 'Passwords do not match.');
    return false;
  }
  clearError('confirm-password');
  return true;
}

function validateAge() {
  const age = Number(document.querySelector('#age').value);
  if (!Number.isFinite(age) || age < 18 || age > 120) {
    showError('age', 'Age must be between 18 and 120.');
    return false;
  }
  clearError('age');
  return true;
}

function validateWebsite() {
  const website = document.querySelector('#website').value.trim();
  if (!website) {
    clearError('website');
    return true;
  }

  if (!website.startsWith('https://')) {
    showError('website', 'Website must start with https://');
    return false;
  }

  clearError('website');
  return true;
}

function validateCountry() {
  const value = document.querySelector('#country').value;
  if (!value) {
    showError('country', 'Please choose a country.');
    return false;
  }
  clearError('country');
  return true;
}

function validateTerms() {
  const checkbox = document.querySelector('#terms');
  if (!checkbox.checked) {
    showError('terms', 'You must accept the terms.');
    return false;
  }
  clearError('terms');
  return true;
}

function updatePasswordStrength(password) {
  const strengthEl = document.querySelector('#password-strength');

  strengthEl.classList.remove('weak', 'fair', 'strong');

  if (password.length === 0) {
    strengthEl.textContent = 'Strength: -';
    return;
  }

  if (password.length < 8) {
    strengthEl.textContent = 'Strength: Weak';
    strengthEl.classList.add('weak');
    return;
  }

  if (/[A-Z]/.test(password) && /\d/.test(password)) {
    strengthEl.textContent = 'Strength: Strong';
    strengthEl.classList.add('strong');
    return;
  }

  strengthEl.textContent = 'Strength: Fair';
  strengthEl.classList.add('fair');
}

const bioTextarea = document.querySelector('#bio');
const charCount = document.querySelector('#char-count');

bioTextarea.addEventListener('input', function() {
  const count = bioTextarea.value.length;
  charCount.textContent = `${count} / 200 characters`;

  if (count > 200) {
    charCount.classList.add('over-limit');
    submitButton.disabled = true;
  } else {
    charCount.classList.remove('over-limit');
    submitButton.disabled = false;
  }
});

document.querySelector('#full-name').addEventListener('blur', validateName);
document.querySelector('#email').addEventListener('blur', validateEmail);
document.querySelector('#password').addEventListener('input', validatePassword);
document.querySelector('#confirm-password').addEventListener('blur', validateConfirmPassword);
document.querySelector('#age').addEventListener('blur', validateAge);
document.querySelector('#website').addEventListener('blur', validateWebsite);
document.querySelector('#country').addEventListener('change', validateCountry);
document.querySelector('#terms').addEventListener('change', validateTerms);

form.addEventListener('submit', function(event) {
  event.preventDefault();

  const results = [
    validateName(),
    validateEmail(),
    validatePassword(),
    validateConfirmPassword(),
    validateAge(),
    validateWebsite(),
    validateCountry(),
    validateTerms(),
    bioTextarea.value.length <= 200,
  ];

  if (results.every(Boolean)) {
    document.querySelector('#success-message').classList.remove('hidden');
    form.classList.add('hidden');
    return;
  }

  const firstInvalid = form.querySelector('.invalid');
  if (firstInvalid) {
    firstInvalid.scrollIntoView({ behavior: 'smooth', block: 'center' });
    firstInvalid.focus();
  }
});
