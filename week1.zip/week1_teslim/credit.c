#include <cs50.h>
#include <stdio.h>

int main(void)
{
    long card = get_long("Number: ");

    int length = 0;
    long number_copy = card;
    while (number_copy > 0)
    {
        length++;
        number_copy /= 10;
    }

    int sum_doubled = 0;
    int sum_rest = 0;

    number_copy = card;
    int i = 0;
    while (number_copy > 0)
    {
        int digit = number_copy % 10;

        if (i % 2 == 1)
        {
            int doubled = digit * 2;
            sum_doubled += doubled / 10 + doubled % 10;
        }
        else
        {
            sum_rest += digit;
        }

        number_copy /= 10;
        i++;
    }

    if ((sum_doubled + sum_rest) % 10 != 0)
    {
        printf("INVALID\n");
        return 0;
    }

    long first2 = card;
    while (first2 >= 100)
    {
        first2 /= 10;
    }

    if (length == 15 && (first2 == 34 || first2 == 37))
    {
        printf("AMEX\n");
    }
    else if (length == 16 && first2 >= 51 && first2 <= 55)
    {
        printf("MASTERCARD\n");
    }
    else if ((length == 13 || length == 16) && first2 / 10 == 4)
    {
        printf("VISA\n");
    }
    else
    {
        printf("INVALID\n");
    }
}
